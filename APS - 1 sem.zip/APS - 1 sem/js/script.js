// Botão de alternância de tema (claro/escuro)
const toggleButton = document.getElementById('toggle-theme');
toggleButton.addEventListener('click', () => {
  document.body.classList.toggle('dark-mode');
});

// Exibe uma saudação ao carregar a página
window.addEventListener('DOMContentLoaded', () => {
  const welcome = document.createElement('div');
  welcome.innerText = "🌱 Bem-vindo à EcoVida!";
  welcome.style.cssText = `
    position: fixed;
    bottom: 1rem;
    right: 1rem;
    background: var(--secondary);
    color: white;
    padding: 0.75rem;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0,0,0,0.2);
    z-index: 1001;
  `;
  window.addEventListener('DOMContentLoaded', () => {
  const navbar = document.querySelector('.navbar');
  const body = document.body;
  
  // Aplica padding-top equivalente à altura da navbar
  const navbarHeight = navbar.offsetHeight;
  body.style.paddingTop = `${navbarHeight}px`;

  // Saudações (como antes)
  const welcome = document.createElement('div');
  welcome.innerText = "🌱 Bem-vindo à EcoVida!";
  welcome.style.cssText = `
    position: fixed;
    bottom: 1rem;
    right: 1rem;
    background: var(--secondary);
    color: white;
    padding: 0.75rem;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0,0,0,0.2);
    z-index: 1001;
  `;
  document.body.appendChild(welcome);
  setTimeout(() => welcome.remove(), 4000);
});

  document.body.appendChild(welcome);

  // Remove após 4 segundos
  setTimeout(() => welcome.remove(), 4000);
});

// Função para alternar o menu responsivo (mobile)
function toggleMenu(button) {
  const menu = document.querySelector('.nav-links');
  const isOpen = menu.classList.toggle('active');
  button.setAttribute('aria-expanded', isOpen);
}
